The runtime/db folder contains the persistent SQLite DB for the OpenACH container.
