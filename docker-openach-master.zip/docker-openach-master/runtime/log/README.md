The runtime/log folder contains the application log files.
