<?php
return array (
  'template' => 'default',
  'tablePrefix' => '',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
);
