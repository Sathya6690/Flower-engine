The distribution comes with a generic self-signed certificate to simplify development and testing.  We highly recommend building your own certificates.  Use the makecerts.sh script to generate an SSL key/cert pair, or provide your own, named as follows:

openach-self-signed.crt
openach-self-signed.key

The default key/cert pair are:

openach-self-signed.crt.dist
openach-self-signed.key.dist
